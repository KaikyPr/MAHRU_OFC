<?php
$servidor = '192.99.36.226';         // Endereço do servidor MySQL (localhost padrão)
$usuario = 'simonato_gordao';               // Usuário padrão do XAMPP
$senha = 'eNbO.Gp)8}lM';      
$banco = 'simonato_MAHRU';      // Nome do banco de dados

try {
    $pdo = new PDO("mysql:host=$servidor;dbname=$banco;charset=utf8mb4", $usuario, $senha);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC); // Boa prática: definir fetch mode padrão

    // --- Verificações e Criações de Tabelas e Colunas ---

    // Tabela usuarios
    $pdo->exec("CREATE TABLE IF NOT EXISTS usuarios (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        senha VARCHAR(255) NOT NULL, -- Aumentado para acomodar hashes
        nivel VARCHAR(20) NOT NULL DEFAULT 'usuario', -- Níveis: 'admin', 'usuario', 'visualizador'
        avatar VARCHAR(255) DEFAULT NULL,
        data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

    // Colunas de reset de senha em usuarios
    try { $pdo->query("SELECT reset_code FROM usuarios LIMIT 1"); } catch (PDOException $e) {
        $pdo->exec("ALTER TABLE usuarios ADD COLUMN reset_code VARCHAR(10) NULL DEFAULT NULL AFTER nivel");
    }
    try { $pdo->query("SELECT reset_expires FROM usuarios LIMIT 1"); } catch (PDOException $e) {
        $pdo->exec("ALTER TABLE usuarios ADD COLUMN reset_expires DATETIME NULL DEFAULT NULL AFTER reset_code");
    }

    // Colunas para mudança de email em usuarios (NOVO)
    try { $pdo->query("SELECT new_email_pending FROM usuarios LIMIT 1"); } catch (PDOException $e) {
        $pdo->exec("ALTER TABLE usuarios ADD COLUMN new_email_pending VARCHAR(100) NULL DEFAULT NULL AFTER reset_expires");
    }
    try { $pdo->query("SELECT email_change_code FROM usuarios LIMIT 1"); } catch (PDOException $e) {
        $pdo->exec("ALTER TABLE usuarios ADD COLUMN email_change_code VARCHAR(10) NULL DEFAULT NULL AFTER new_email_pending");
    }
    try { $pdo->query("SELECT email_change_expires FROM usuarios LIMIT 1"); } catch (PDOException $e) {
        $pdo->exec("ALTER TABLE usuarios ADD COLUMN email_change_expires DATETIME NULL DEFAULT NULL AFTER email_change_code");
    }
    
    // Colunas adicionais para verificação do novo email
    try { $pdo->query("SELECT new_email_code FROM usuarios LIMIT 1"); } catch (PDOException $e) {
        $pdo->exec("ALTER TABLE usuarios ADD COLUMN new_email_code VARCHAR(10) NULL DEFAULT NULL AFTER email_change_expires");
    }
    try { $pdo->query("SELECT new_email_code_expires FROM usuarios LIMIT 1"); } catch (PDOException $e) {
        $pdo->exec("ALTER TABLE usuarios ADD COLUMN new_email_code_expires DATETIME NULL DEFAULT NULL AFTER new_email_code");
    }

    // Usuário admin padrão
    $query = $pdo->query("SELECT COUNT(*) FROM usuarios WHERE nivel = 'admin'");
    if ($query->fetchColumn() == 0) {
        $nome = 'Administrador';
        $email = 'admin@mahru.com';
        $senha_hashed = password_hash('admin', PASSWORD_DEFAULT);
        $nivel = 'admin';
        $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, nivel) VALUES (:nome, :email, :senha, :nivel)");
        $stmt->execute([':nome' => $nome, ':email' => $email, ':senha' => $senha_hashed, ':nivel' => $nivel]);
    }

    // Tabela hacks
    $pdo->exec("CREATE TABLE IF NOT EXISTS hacks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        descricao TEXT NOT NULL,
        piso INT NOT NULL,
        tipo VARCHAR(20) NOT NULL,
        imagem VARCHAR(255) NOT NULL,
        usuario_id INT DEFAULT NULL,
        status VARCHAR(20) DEFAULT 'ativo',
        latitude VARCHAR(50) DEFAULT NULL, -- Considerar usar DECIMAL(10,8) ou similar
        longitude VARCHAR(50) DEFAULT NULL, -- Considerar usar DECIMAL(11,8) ou similar
        data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

    // Colunas faltantes em hacks (verificações de segurança)
    try { $pdo->query("SELECT usuario_id FROM hacks LIMIT 1"); } catch (PDOException $e) {
        $pdo->exec("ALTER TABLE hacks ADD COLUMN usuario_id INT DEFAULT NULL");
        $pdo->exec("ALTER TABLE hacks ADD CONSTRAINT fk_usuario_id FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL");
    }
    try { $pdo->query("SELECT status FROM hacks LIMIT 1"); } catch (PDOException $e) {
        $pdo->exec("ALTER TABLE hacks ADD COLUMN status VARCHAR(20) DEFAULT 'ativo'");
    }
    try { $pdo->query("SELECT latitude FROM hacks LIMIT 1"); } catch (PDOException $e) {
        $pdo->exec("ALTER TABLE hacks ADD COLUMN latitude VARCHAR(50) DEFAULT NULL");
    }
    try { $pdo->query("SELECT longitude FROM hacks LIMIT 1"); } catch (PDOException $e) {
        $pdo->exec("ALTER TABLE hacks ADD COLUMN longitude VARCHAR(50) DEFAULT NULL");
    }

    // Tabela comentarios (NOVO - se não existir no dump original)
    $pdo->exec("CREATE TABLE IF NOT EXISTS comentarios (
        id INT AUTO_INCREMENT PRIMARY KEY,
        hack_id INT NOT NULL,
        usuario_id INT NOT NULL,
        comentario TEXT NOT NULL,
        data_comentario TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (hack_id) REFERENCES hacks(id) ON DELETE CASCADE,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

    // Tabela logs (NOVO - se não existir no dump original)
    $pdo->exec("CREATE TABLE IF NOT EXISTS logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        usuario_id INT DEFAULT NULL,
        acao VARCHAR(255) NOT NULL,
        detalhes TEXT DEFAULT NULL,
        ip_address VARCHAR(45) DEFAULT NULL,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

} catch (PDOException $e) {
    error_log("Erro de conexão/configuração PDO: " . $e->getMessage());
    die("Erro na conexão ou configuração do banco de dados. Verifique os logs do servidor.");
}
?>
