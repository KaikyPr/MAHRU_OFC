    </div> <!-- Fecha a div #app iniciada no header.php -->

    <!-- Bootstrap JS (já incluído em muitas páginas, mas pode ser global aqui) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Scripts JS Globais -->
    <script>
        // Script GLOBAL para animação de carregamento
        document.addEventListener('DOMContentLoaded', function() {
            // Esconde o overlay após o carregamento inicial (com um pequeno delay)
            const loadingOverlay = document.getElementById('loading-overlay');
            const appContent = document.getElementById('app');

            // Garante que o overlay esteja visível inicialmente
            if (loadingOverlay) {
                loadingOverlay.style.display = 'flex';
            }
            if (appContent) {
                appContent.classList.add('hidden-content'); // Mantém conteúdo oculto inicialmente
            }

            // Adiciona um tempo mínimo de visualização do loading
            setTimeout(function() {
                if (loadingOverlay) {
                    loadingOverlay.classList.add('fade-out');
                }
                if (appContent) {
                    appContent.classList.remove('hidden-content');
                }

                // Remove o overlay do DOM após a animação para não interferir
                setTimeout(function() {
                    if (loadingOverlay) {
                        loadingOverlay.style.display = 'none';
                    }
                }, 500); // Tempo correspondente à transição de opacidade no CSS
            }, 500); // Tempo mínimo de exibição do loading (ajuste conforme necessário)
        });

        // Interceptar cliques em links e submissões de formulário para mostrar animação
        document.addEventListener('click', function(e) {
            let targetElement = e.target;
            let link = null;

            // Verifica se o clique foi em um link ou dentro de um link
            if (targetElement.tagName === 'A') {
                link = targetElement;
            } else {
                link = targetElement.closest('a');
            }

            if (link && link.href && link.href !== '#' && !link.href.startsWith('javascript:') && !link.classList.contains('dropdown-toggle') && !link.hasAttribute('data-bs-toggle') && link.target !== '_blank') {
                // Verifica se é um link interno (mesmo host) ou relativo
                if (link.hostname === window.location.hostname || !link.hostname) {
                    e.preventDefault(); // Previne a navegação imediata
                    const loadingOverlay = document.getElementById('loading-overlay');
                    const appContent = document.getElementById('app');

                    if (loadingOverlay) {
                        loadingOverlay.classList.remove('fade-out');
                        loadingOverlay.style.opacity = '1'; // Garante opacidade total
                        loadingOverlay.style.display = 'flex'; // Mostra o overlay
                    }
                    if (appContent) {
                        // Opcional: Ocultar conteúdo novamente
                        // appContent.classList.add('hidden-content');
                    }

                    // Aguarda um curto período para a animação ser visível e então navega
                    setTimeout(function() {
                        window.location.href = link.href;
                    }, 150); // Pequeno delay para garantir que o overlay apareça
                }
            }
        });

        // Interceptar submissão de formulários
        document.addEventListener('submit', function(e) {
            const form = e.target;
            // Adicionar verificação se o formulário não tem target="_blank"
            if (form && form.method.toLowerCase() !== 'dialog' && form.target !== '_blank') {
                 const loadingOverlay = document.getElementById('loading-overlay');
                 const appContent = document.getElementById('app');

                 if (loadingOverlay) {
                     loadingOverlay.classList.remove('fade-out');
                     loadingOverlay.style.opacity = '1';
                     loadingOverlay.style.display = 'flex';
                 }
                 if (appContent) {
                    // Opcional: Ocultar conteúdo novamente
                    // appContent.classList.add('hidden-content');
                 }
                 // Não prevenimos o default, apenas mostramos o loading.
                 // Para formulários que submetem via JS/AJAX, o loading precisaria ser tratado no callback.
            }
        });

        // Script para toggle da sidebar (se aplicável globalmente)
        const sidebarToggle = document.querySelector('[data-toggle="sidebar"]');
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function(e) {
                e.preventDefault();
                document.body.classList.toggle('sidebar-mini'); // Ou a classe que controla o estado da sidebar
                // Ajuste a classe conforme a implementação da sua sidebar (ex: 'sidebar-gone')
            });
        }

    </script>

    <!-- Scripts JS específicos da página (se houver) -->
    <?php if (isset($page_js)): ?>
        <script src="<?php echo $page_js; ?>"></script>
    <?php endif; ?>

</body>
</html>

