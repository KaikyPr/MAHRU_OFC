<?php
// Este arquivo pode conter código PHP comum para o cabeçalho,
// como inicialização de sessão, verificação de login, etc.

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Gerar token CSRF se não existir
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Obter informações do usuário logado para Navbar/Sidebar
$usuario_id_logado = $_SESSION["usuario_id"] ?? null;
$nome_usuario_logado = "Visitante";
$avatar_usuario_logado = "img/img-sem-foto.jpg"; // Default avatar
$nivel_usuario_logado = "visitante"; // Nível padrão

if ($usuario_id_logado) {
    // Assumindo que as variáveis de sessão já contêm o necessário
    $nome_usuario_logado = $_SESSION["usuario_nome"] ?? "Usuário";
    $avatar_path_session = $_SESSION["usuario_avatar"] ?? null;
    $nivel_usuario_logado = $_SESSION["usuario_nivel"] ?? "usuario";

    // Define the default avatar path (web relative)
    $default_avatar_web_path = "img/img-sem-foto.jpg";
    $avatar_usuario_logado = $default_avatar_web_path; // Start with default

    // Check if a specific avatar path is set in the session
    if (!empty($avatar_path_session)) {
        // Construct the full filesystem path for file_exists check
        // header.php is in includes/, avatar paths (like uploads/avatares/...) are relative to the parent dir
        $avatar_filesystem_path = __DIR__ . '/../' . $avatar_path_session;

        // Check if the file exists and is readable on the server
        if (file_exists($avatar_filesystem_path) && is_readable($avatar_filesystem_path)) {
            // If it exists, use the web-relative path stored in the session for the src attribute
            $avatar_usuario_logado = $avatar_path_session;
        } else {
            // Se o arquivo não existir, atualizar a sessão para usar o padrão
            $_SESSION["usuario_avatar"] = $default_avatar_web_path;
        }
    } else {
        // Se o caminho estiver vazio, atualizar a sessão para usar o padrão
        $_SESSION["usuario_avatar"] = $default_avatar_web_path;
    }
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/Design_sem_nome-removebg-preview.ico" type="image/x-icon">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) : "MAHRU"; ?></title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="styles/style.css">
    <!-- Animações -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

    <!-- Estilos específicos da página (se houver) -->
    <?php if (isset($page_css)): ?>
        <link rel="stylesheet" href="<?php echo htmlspecialchars($page_css); ?>">
    <?php endif; ?>
</head>
<body>
    <!-- Overlay de carregamento GLOBAL -->
    <div id="loading-overlay">
        <div class="spinner">
            <div class="double-bounce1"></div>
            <div class="double-bounce2"></div>
        </div>
        <div class="loading-text">Carregando MAHRU</div>
    </div>

    <!-- Conteúdo principal envolto para controle de visibilidade -->
    <div id="app" class="hidden-content">
        <div class="main-wrapper">
            <!-- Navbar GLOBAL -->
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
                <form class="form-inline me-auto">
                    <ul class="navbar-nav me-3">
                        <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
                    </ul>
                </form>
                <ul class="navbar-nav navbar-right ms-auto">
                    <?php if ($usuario_id_logado): // Só mostra dropdown se logado ?>
                    <li class="dropdown">
                        <a href="#" class="nav-link dropdown-toggle nav-link-user" data-bs-toggle="dropdown">
                            <!-- Exibe o avatar verificado -->
                            <img alt="Avatar" src="<?php echo htmlspecialchars($avatar_usuario_logado); ?>" class="rounded-circle me-1">
                            <div class="d-none d-lg-inline-block user-greeting">Olá, <?php echo htmlspecialchars($nome_usuario_logado); ?></div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <div class="dropdown-title">Gerenciar Perfil</div>
                            <a href="editar-perfil.php" class="dropdown-item">
                                <i class="fas fa-user me-2"></i> Meu Perfil
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="logout.php" class="dropdown-item text-danger">
                                <i class="fas fa-sign-out-alt me-2"></i> Sair
                            </a>
                        </div>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>

            <!-- Sidebar GLOBAL -->
            <?php if ($usuario_id_logado): // Só mostra sidebar se logado ?>
            <div class="main-sidebar sidebar-style-2">
                <aside id="sidebar-wrapper">
                    <div class="sidebar-brand">
                        <a href="painel.php">MAHRU</a>
                    </div>
                    <ul class="sidebar-menu">
                        <li class="menu-header">Principal</li>
                        <li class="<?php echo basename($_SERVER["PHP_SELF"]) == "painel.php" ? "active" : ""; ?>"><a class="nav-link" href="painel.php"><i class="fas fa-fire"></i> <span>Visão Geral</span></a></li>
                        
                        <li class="menu-header">Gerenciamento</li>
                        <li class="<?php echo basename($_SERVER["PHP_SELF"]) == "index.php" ? "active" : ""; ?>"><a class="nav-link" href="index.php"><i class="fas fa-th-large"></i> <span>Visualizar Hacks</span></a></li>
                        <li class="<?php echo basename($_SERVER["PHP_SELF"]) == "cadastrar_hack.php" ? "active" : ""; ?>"><a class="nav-link" href="cadastrar_hack.php"><i class="fas fa-plus-circle"></i> <span>Cadastrar Hack</span></a></li>
                        
                        <?php if ($nivel_usuario_logado === "admin"): ?>
                        <li class="menu-header">Administração</li>
                        <li class="<?php echo basename($_SERVER["PHP_SELF"]) == "cadastrar_usuario.php" ? "active" : ""; ?>"><a class="nav-link" href="cadastrar_usuario.php"><i class="fas fa-user-plus"></i> <span>Cadastrar Usuário</span></a></li>
                        <?php endif; ?>
                        
                        <li class="menu-header">Configurações</li>
                        <li class="<?php echo basename($_SERVER["PHP_SELF"]) == "editar-perfil.php" ? "active" : ""; ?>"><a class="nav-link" href="editar-perfil.php"><i class="fas fa-user-cog"></i> <span>Meu Perfil</span></a></li>
                        <li><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
                    </ul>
                </aside>
            </div>
            <?php endif; ?>

            <!-- O conteúdo específico da página será inserido aqui pelas páginas que incluem este header -->
            <!-- Exemplo: <div class="main-content">...</div> -->
