<?php
/**
 * Arquivo para verificação e alteração de senha administrativa
 * 
 * Este arquivo contém funções para verificar e alterar a senha administrativa
 * utilizada para operações sensíveis no sistema MAHRU.
 */

// Caminho para o arquivo de configuração de senha
define('SENHA_CONFIG_FILE', __DIR__ . '/config_senha.php');

// Função para verificar se a senha fornecida é válida para operações administrativas
function verificar_senha_admin($senha_fornecida) {
    // Inclui o arquivo de configuração de senha
    require_once(SENHA_CONFIG_FILE);
    
    // Verifica se a senha fornecida corresponde à senha do sistema
    return $senha_fornecida === $senha_admin_sistema;
}

// Função para alterar a senha administrativa
function alterar_senha_admin($nova_senha, $codigo_verificacao = null) {
    // Se um código de verificação for fornecido, verificar se é válido
    if ($codigo_verificacao !== null) {
        // Aqui seria implementada a verificação do código enviado por email
        // Por enquanto, retorna falso se o código for fornecido mas não implementado
        return false;
    }
    
    // Lê o conteúdo atual do arquivo
    $conteudo = file_get_contents(SENHA_CONFIG_FILE);
    
    // Substitui a senha atual pela nova senha
    $conteudo = preg_replace(
        '/\$senha_admin_sistema\s*=\s*"[^"]*"/',
        '$senha_admin_sistema = "' . $nova_senha . '"',
        $conteudo
    );
    
    // Escreve o conteúdo atualizado de volta no arquivo
    return file_put_contents(SENHA_CONFIG_FILE, $conteudo) !== false;
}
