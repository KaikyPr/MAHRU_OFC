<?php
/**
 * Arquivo de configuração para senha de administração do sistema
 * Este arquivo deve ter permissões restritas no servidor de produção
 */

// Senha necessária para salvar alterações no sistema
$senha_admin_sistema = "admin123"; // Altere esta senha para uma senha forte em ambiente de produção

// Função para verificar se a senha fornecida é válida para operações administrativas
function verificar_senha_admin($senha_fornecida) {
    global $senha_admin_sistema;
    return $senha_fornecida === $senha_admin_sistema;
}
?>
