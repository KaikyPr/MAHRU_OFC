// Script para animações durante a rolagem da página
window.addEventListener('scroll', () => {
    const sections = document.querySelectorAll('.animate-on-scroll');
    sections.forEach((section) => {
        const sectionTop = section.getBoundingClientRect().top;
        if (sectionTop < window.innerHeight - 100) {
            section.classList.add('visible');
        }
    });
});
