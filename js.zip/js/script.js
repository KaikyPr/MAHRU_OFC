document.querySelector('.btn').addEventListener('mouseover', () => {
    document.body.style.cursor = 'pointer';
});

document.querySelector('.btn').addEventListener('mouseout', () => {
    document.body.style.cursor = 'default';
});
